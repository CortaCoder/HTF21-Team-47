from django.contrib import admin

from Home.forms import SellerForm
from Home.models import seller

# Register your models here.
@admin.register(seller)
class AllEntiryAdmin(admin.ModelAdmin):
    list_display = ("item_name", "item_desc","item_sbid","item_tlim")