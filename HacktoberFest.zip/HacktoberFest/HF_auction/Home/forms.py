from .models import seller
from . import models
from django.forms import ModelForm

class SellerForm(ModelForm):
    class Meta:
        model=seller
        fields=['item_name','item_desc','item_sbid','item_tlim']