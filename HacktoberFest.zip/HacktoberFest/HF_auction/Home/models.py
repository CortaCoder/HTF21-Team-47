from django.db import models

# Create your models here
class seller(models.Model):
    item_name= models.CharField(max_length=50)
    item_image=models.ImageField(upload_to ='seller_pics/')
    item_desc=models.TextField()
    item_sbid=models.IntegerField()
    item_tlim=models.DateTimeField()
    name=models.CharField(max_length=50,default="Secure Auc")