from django.shortcuts import render
from django.http import HttpResponse
from . import urls
from .forms import SellerForm
from .models import seller
# Create your views here.

def seller_host(request):
    if request.method=='POST':
        form=SellerForm(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return HttpResponse("Hi")
        return HttpResponse("Bye")
    else:
        form=SellerForm()
    return render(request,'inner-page1.html',context={'form':form})

def auction_display(request):
    sellers=seller.objects.all()
    context={
        'sellers':sellers
    }
    return render(request,"blog.html",context)

def display_home(request):
    return render(request,'index.html')